import java.util.List;

/**
 *
 * @author koosha
 */
public class Trip 
{
    public List<Place> visitedList;
    public double tourLength;
    public double remainingTourLength;
    public double score;
    
}
