
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author koosha
 */
public class Agent extends Thread {

    public Hotel[] hotelsList;
    public Place[] placeList;
    public int numberOfVertices;
    public int numberOfExtraHotels;
    public int numberOfPlaces;
    public int numberOfTrips;
    public int totalTourLength;
    public List<Double> tripLengthForEachTrip;
    public List tripsList;
    public Grasp gr;
    public SimulatedAnnealing sm;
    public TabooSearch tbs;
    public GeneticAlgorithm ge;
    Double[][] hotelMatrix;
    Double[][] placeMatrix;
    List<Trip[]> Generation;
    public int time;

    public Agent(int _numberOfVertices, int _numberOfExtraHotels, int _numberOfPlaces, int _numberOfTrips, int _totalTourLength, List _tripLengthForEachTrip, Hotel[] _hotelsList, Place[] _placeList) {
        numberOfVertices = _numberOfVertices;
        numberOfExtraHotels = _numberOfExtraHotels;
        numberOfPlaces = _numberOfPlaces;
        numberOfTrips = _numberOfTrips;
        totalTourLength = _totalTourLength;
        tripLengthForEachTrip = _tripLengthForEachTrip;
        hotelsList = _hotelsList;
        placeList = _placeList;
        //  BestSolution = new Trip[numberOfTrips];   
        //  time=_time;
    }

    @Override
    public void run() {
          try {
        //ge = new GeneticAlgorithm(numberOfVertices, numberOfExtraHotels, numberOfPlaces, numberOfTrips, totalTourLength, tripLengthForEachTrip, hotelsList, placeList);

        new TimeLimit(time * 1000, new ExceptionRunnable() {
            @Override
            public void run() throws Exception {
                // for(int i=0;i<10;i++)
                // {
                Generation = new ArrayList();
                hotelMatrix = new Double[hotelsList.length][hotelsList.length];
                for (int s = 0; s < ge.hotelsList.length; s++) {
                    for (int j = 0; j < ge.hotelsList.length; j++) {
                        hotelMatrix[s][j] = ge.FindDistance(ge.hotelsList[s].x, ge.hotelsList[s].y, ge.hotelsList[j].x, ge.hotelsList[j].y);
                    }
                }

                for (int i = 0; i <400; i++) {
                    Trip[] NewSolution = new Trip[numberOfTrips];
                    for (int j = 0; j < NewSolution.length; j++) {
                        NewSolution[j] = new Trip();
                        NewSolution[j].remainingTourLength = ge.tripLengthForEachTrip.get(j);
                        NewSolution[j].score = 0;
                        NewSolution[j].tourLength = 0;

                    }
                    Trip[] temp = new Trip[numberOfTrips];
                    for (int j = 0; j < numberOfTrips; j++) {
                        temp[j] = new Trip();
                        NewSolution[j] = new Trip();
                        temp[j].remainingTourLength = ge.tripLengthForEachTrip.get(j);
                        temp[j].score = 0;
                        temp[j].tourLength = 0;
                    }
                    for (int j = 0; j < temp.length; j++) {
                        temp[j].visitedList = new ArrayList();
                    }
                    ge.initialization();

                    temp = ge.CreateSolution(temp, hotelMatrix);
                    for (int j = 0; j < temp.length; j++) {

                        NewSolution[j].score = temp[j].score;
                        NewSolution[j].remainingTourLength = temp[j].remainingTourLength;
                        NewSolution[j].tourLength = temp[j].tourLength;
                        NewSolution[j].visitedList = new ArrayList();
                        for (int k = 0; k < temp[j].visitedList.size(); k++) {
                            NewSolution[j].visitedList.add(temp[j].visitedList.get(k));
                        }
                    }
                    Generation.add(NewSolution);
                    if (ge.BestSolution[0] != null) {
                        if (ge.SolutionTotalScore(NewSolution) > ge.SolutionTotalScore(ge.BestSolution)) {
                            ge.BestSolution = new Trip[NewSolution.length];
                            for (int l = 0; l < NewSolution.length; l++) {
                                ge.BestSolution[l] = new Trip();
                                ge.BestSolution[l].remainingTourLength = NewSolution[l].remainingTourLength;
                                ge.BestSolution[l].score = NewSolution[l].score;
                                ge.BestSolution[l].tourLength = NewSolution[l].tourLength;
                                ge.BestSolution[l].visitedList = new ArrayList();
                                for (int j = 0; j < NewSolution[l].visitedList.size(); j++) {
                                    ge.BestSolution[l].visitedList.add(NewSolution[l].visitedList.get(j));
                                }
                            }
                        }
                    } else {
                        ge.BestSolution = new Trip[NewSolution.length];
                        for (int l = 0; l < NewSolution.length; l++) {
                            ge.BestSolution[l] = new Trip();
                            ge.BestSolution[l].remainingTourLength = NewSolution[l].remainingTourLength;
                            ge.BestSolution[l].score = NewSolution[l].score;
                            ge.BestSolution[l].tourLength = NewSolution[l].tourLength;
                            ge.BestSolution[l].visitedList = new ArrayList();
                            for (int j = 0; j < NewSolution[l].visitedList.size(); j++) {
                                ge.BestSolution[l].visitedList.add(NewSolution[l].visitedList.get(j));
                            }
                        }
                    }

                }

                while (true) {
                    double generationScore = 0;
                    for (int i = 0; i < Generation.size(); i++) {
                        generationScore += ge.SolutionTotalScore(Generation.get(i));
                    }
                    List<Trip[]> parentList = new ArrayList();
                    List<Trip[]> childrenList = new ArrayList();
                    while (parentList.size() != 10) {
                        Random r = new Random();
                        int index = r.nextInt(400);
                        int rand = r.nextInt(100);
                        if (rand / 100 <= ge.SolutionTotalScore(Generation.get(index)) / generationScore) {
                            parentList.add(Generation.get(index));
                        }
                    }
                    while (childrenList.size() != 50) {
                        x(childrenList, parentList);
                    }
                    while (childrenList.size() > 0) {
                        Random r = new Random();
                        int ind = r.nextInt(Generation.size());
                        int index = r.nextInt(400);
                        int rand = r.nextInt(100);
                        if (rand / 100 > ge.SolutionTotalScore(Generation.get(index)) / generationScore) {
                            Generation.remove(index);
                        }

                        Generation.add(childrenList.get(childrenList.size() - 1));
                        childrenList.remove(childrenList.size() - 1);
                    }

                }
            }}

          ).run();
        }
            catch (Throwable t)  
            {

                }
          }
    public void x(List<Trip[]> childrenList, List<Trip[]> parentList) {
        int flag = 0;
        // for(int i=0;i<parentList.size();i+=2)
        Random r = new Random();
        int index1 = r.nextInt(numberOfTrips);
        int parentOneID = r.nextInt(parentList.size());
        int parentTwoID = r.nextInt(parentList.size());
        Trip[] child = new Trip[ge.numberOfTrips];
        for (int y = 0; y < ge.numberOfTrips; y++) {
            child[y] = new Trip();
        }
        //if (index1 > 0) {
        for (int u = 0; u < index1; u++) {
            child[u].remainingTourLength = tripLengthForEachTrip.get(u);
            child[u].score = 0;
            child[u].tourLength = 0;
            child[u].visitedList = new ArrayList();

            for (int h = 0; h < parentList.get(parentOneID)[u].visitedList.size(); h++) {

                child[u].visitedList.add(parentList.get(parentOneID)[u].visitedList.get(h));
            }
          /*  if (child[u].visitedList.size() > 2) {
                for (int f = 2; f < child[u].visitedList.size(); f++) {

                    if (f == 2 && f != child[u].visitedList.size() - 1) {
                        child[u].score += child[u].visitedList.get(f).score;
                        child[u].remainingTourLength -= ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y);
                        child[u].tourLength += ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y);
                        //   break;
                    }
                    if (f == 2 && f == child[u].visitedList.size() - 1) {
                        child[u].score += child[u].visitedList.get(f).score;
                        child[u].remainingTourLength -= (ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y));
                        child[u].tourLength += (ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y) + ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(f - 2).x, child[u].visitedList.get(f - 2).y));
                        // break;
                    }
                    if (f != 2 && f == child[u].visitedList.size() - 1) {
                        child[u].score += child[u].visitedList.get(f).score;
                        child[u].remainingTourLength -= (ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(f - 1).x, child[u].visitedList.get(f - 1).y));
                        child[u].tourLength += (ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y) + ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(f - 1).x, child[u].visitedList.get(f - 1).y));
                        // break;
                    }
                    if (f > 2 && f != child[u].visitedList.size() - 1) {
                        child[u].score += child[u].visitedList.get(f).score;
                        child[u].remainingTourLength -= ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(f - 1).x, child[u].visitedList.get(f - 1).y);
                        child[u].tourLength += ge.FindDistance(child[u].visitedList.get(f).x, child[u].visitedList.get(f).y, child[u].visitedList.get(f - 1).x, child[u].visitedList.get(f - 1).y);
                        // break;
                    }
                }
            } else {
                child[u].tourLength += ge.FindDistance(child[u].visitedList.get(0).x, child[u].visitedList.get(0).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y);
            }*/
            // break;
        }

        List<Trip> selected = new ArrayList();
        for (int u = index1; u < child.length; u++) {
            if (u == child.length - 1) {
                for (int k = 0; k < child.length; k++) {
                    if (hotelMatrix[Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(0).ID)][Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(1).ID)] <= ge.tripLengthForEachTrip.get(u) && Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(0).ID) == Integer.parseInt(child[u - 1].visitedList.get(1).ID) && Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(1).ID) == 1 && !selected.contains(parentList.get(parentTwoID)[k])) {
                        child[u].remainingTourLength = tripLengthForEachTrip.get(u);
                        child[u].score = 0;
                        child[u].tourLength = 0;
                        child[u].visitedList = new ArrayList();
                        for (int h = 0; h < parentList.get(parentTwoID)[k].visitedList.size(); h++) {

                            child[u].visitedList.add(parentList.get(parentTwoID)[k].visitedList.get(h));
                        }
                      /*  if (child[u].visitedList.size() > 2) {
                            for (int v = 2; v < child[u].visitedList.size(); v++) {

                                //child[j].visitedList.add(parentList.get(parentTwoID)[j].visitedList.get(v));
                                if (v == 2 && v != child[u].visitedList.size() - 1) {
                                    child[u].score += child[u].visitedList.get(v).score;
                                    child[u].remainingTourLength -= ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y);
                                    child[u].tourLength += ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y);
                                    // break;
                                }
                                if (v == 2 && v == child[u].visitedList.size() - 1) {
                                    child[u].score += child[u].visitedList.get(v).score;
                                    child[u].remainingTourLength -= (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y));
                                    child[u].tourLength += (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y) + ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 2).x, child[u].visitedList.get(v - 2).y));
                                    // break;
                                }
                                if (v != 2 && v == child[u].visitedList.size() - 1) {
                                    child[u].score += child[u].visitedList.get(v).score;
                                    child[u].remainingTourLength -= (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y));
                                    child[u].tourLength += (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y) + ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y));
                                    // break;
                                }
                                if (v > 2 && v != child[u].visitedList.size() - 1) {
                                    child[u].score += child[u].visitedList.get(v).score;
                                    child[u].remainingTourLength -= ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y);
                                    child[u].tourLength += ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y);
                                    // break;
                                }
                            }
                        } else {
                            child[u].tourLength += ge.FindDistance(child[u].visitedList.get(0).x, child[u].visitedList.get(0).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y);
                        }*/
                        break;
                    } else {

                        if (k == child.length - 1) {
                            //x(childrenList, parentList);
                            //flag = 1;
                            // break;
                            return;
                        }
                    }
                }

            } else {

                if (u > 0) {
                    for (int k = 0; k < child.length; k++) {
                        if (hotelMatrix[Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(0).ID)][Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(1).ID)] <= ge.tripLengthForEachTrip.get(u) && Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(0).ID) == Integer.parseInt(child[u - 1].visitedList.get(1).ID) && !selected.contains(parentList.get(parentTwoID)[k])) {
                            selected.add(parentList.get(parentTwoID)[k]);
                            child[u].remainingTourLength = tripLengthForEachTrip.get(u);
                            child[u].score = 0;
                            child[u].tourLength = 0;
                            child[u].visitedList = new ArrayList();
                            for (int h = 0; h < parentList.get(parentTwoID)[k].visitedList.size(); h++) {

                                child[u].visitedList.add(parentList.get(parentTwoID)[k].visitedList.get(h));
                            }
                        /*    if (child[u].visitedList.size() > 2) {
                                for (int v = 2; v < child[u].visitedList.size(); v++) {

                                    //child[j].visitedList.add(parentList.get(parentTwoID)[j].visitedList.get(v));
                                    if (v == 2 && v != child[u].visitedList.size() - 1) {
                                        child[u].score += child[u].visitedList.get(v).score;
                                        child[u].remainingTourLength -= ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y);
                                        child[u].tourLength += ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y);
                                        // break;
                                    }
                                    if (v == 2 && v == child[u].visitedList.size() - 1) {
                                        child[u].score += child[u].visitedList.get(v).score;
                                        child[u].remainingTourLength -= (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y));
                                        child[u].tourLength += (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y) + ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 2).x, child[u].visitedList.get(v - 2).y));
                                        // break;
                                    }
                                    if (v != 2 && v == child[u].visitedList.size() - 1) {
                                        child[u].score += child[u].visitedList.get(v).score;
                                        child[u].remainingTourLength -= (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y));
                                        child[u].tourLength += (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y) + ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y));
                                        // break;
                                    }
                                    if (v > 2 && v != child[u].visitedList.size() - 1) {
                                        child[u].score += child[u].visitedList.get(v).score;
                                        child[u].remainingTourLength -= ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y);
                                        child[u].tourLength += ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y);
                                        // break;
                                    }
                                }
                            } else {
                                child[u].tourLength += ge.FindDistance(child[u].visitedList.get(0).x, child[u].visitedList.get(0).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y);
                            }*/
                            break;
                        } else {
                            if (k == child.length - 1) {
                                //x(childrenList, parentList);
                                //flag = 1;
                                //break;
                                return;
                            }
                        }
                    }
                } else {
                    for (int k = 0; k < child.length; k++) {
                        if (hotelMatrix[Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(0).ID)][Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(1).ID)] <= ge.tripLengthForEachTrip.get(u) && Integer.parseInt(parentList.get(parentTwoID)[k].visitedList.get(0).ID) == 0 && !selected.contains(parentList.get(parentTwoID)[k])) {
                            selected.add(parentList.get(parentTwoID)[k]);
                            child[u].remainingTourLength = tripLengthForEachTrip.get(u);
                            child[u].score = 0;
                            child[u].tourLength = 0;
                            child[u].visitedList = new ArrayList();
                            for (int h = 0; h < parentList.get(parentTwoID)[k].visitedList.size(); h++) {

                                child[u].visitedList.add(parentList.get(parentTwoID)[k].visitedList.get(h));
                            }
                          /*  if (child[u].visitedList.size() > 2) {
                                for (int v = 2; v < child[u].visitedList.size(); v++) {

                                    //child[j].visitedList.add(parentList.get(parentTwoID)[j].visitedList.get(v));
                                    if (v == 2 && v != child[u].visitedList.size() - 1) {
                                        child[u].score += child[u].visitedList.get(v).score;
                                        child[u].remainingTourLength -= ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y);
                                        child[u].tourLength += ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y);
                                        //  break;
                                    }
                                    if (v == 2 && v == child[u].visitedList.size() - 1) {
                                        child[u].score += child[u].visitedList.get(v).score;
                                        child[u].remainingTourLength -= (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(0).x, child[u].visitedList.get(0).y));
                                        child[u].tourLength += (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y) + ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 2).x, child[u].visitedList.get(v - 2).y));
                                        //break;
                                    }
                                    if (v != 2 && v == child[u].visitedList.size() - 1) {
                                        child[u].score += child[u].visitedList.get(v).score;
                                        child[u].remainingTourLength -= (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y));
                                        child[u].tourLength += (ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y) + ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y));
                                        // break;
                                    }
                                    if (v > 2 && v != child[u].visitedList.size() - 1) {
                                        child[u].score += child[u].visitedList.get(v).score;
                                        child[u].remainingTourLength -= ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y);
                                        child[u].tourLength += ge.FindDistance(child[u].visitedList.get(v).x, child[u].visitedList.get(v).y, child[u].visitedList.get(v - 1).x, child[u].visitedList.get(v - 1).y);
                                        //  break;
                                    }
                                }
                            } else {
                                child[u].tourLength += ge.FindDistance(child[u].visitedList.get(0).x, child[u].visitedList.get(0).y, child[u].visitedList.get(1).x, child[u].visitedList.get(1).y);
                            }*/
                            break;
                        } else {
                            if (k == child.length - 1) {
                                //x(childrenList, parentList);
                                //flag = 1;
                                // break;
                                return;
                            }
                        }
                    }
                }
            }
        }
        //  }

        /*if (flag == 1) {
           x(childrenList, parentList);
        } else {*/
        for (int i = 0; i < child.length - 1; i++) {
            for (int s = i + 1; s < child.length; s++) {
                if (child[i].visitedList.size() > 2) {
                    for (int jj = 2; jj < child[i].visitedList.size(); jj++) {

                        if (child[s].visitedList.size() > 2 && child[s].visitedList.contains(child[i].visitedList.get(jj))) {
                    /*        if (jj < child[i].visitedList.size() - 1) {
                                child[s].tourLength -= ge.FindDistance(child[i].visitedList.get(jj).x, child[i].visitedList.get(jj).y, child[i].visitedList.get(jj - 1).x, child[i].visitedList.get(jj - 1).y) + ge.FindDistance(child[i].visitedList.get(jj).x, child[i].visitedList.get(jj).y, child[i].visitedList.get(jj + 1).x, child[i].visitedList.get(jj + 1).y);
                                child[s].tourLength += ge.FindDistance(child[i].visitedList.get(jj - 1).x, child[i].visitedList.get(jj - 1).y, child[i].visitedList.get(jj + 1).x, child[i].visitedList.get(jj + 1).y);
                                child[s].remainingTourLength += ge.FindDistance(child[i].visitedList.get(jj).x, child[i].visitedList.get(jj).y, child[i].visitedList.get(jj - 1).x, child[i].visitedList.get(jj - 1).y);
                                child[s].score -= child[i].visitedList.get(jj).score;
                                child[s].visitedList.remove(child[i].visitedList.get(jj));
                            }
                            if (jj == child[i].visitedList.size() - 1) {
                                child[s].tourLength -= ge.FindDistance(child[i].visitedList.get(jj).x, child[i].visitedList.get(jj).y, child[i].visitedList.get(jj - 1).x, child[i].visitedList.get(jj - 1).y) + ge.FindDistance(child[i].visitedList.get(jj).x, child[i].visitedList.get(jj).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y);
                                child[s].tourLength += ge.FindDistance(child[i].visitedList.get(jj - 1).x, child[i].visitedList.get(jj - 1).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y);
                                child[s].remainingTourLength += ge.FindDistance(child[i].visitedList.get(jj).x, child[i].visitedList.get(jj).y, child[i].visitedList.get(jj - 1).x, child[i].visitedList.get(jj - 1).y);
                                child[s].score -= child[i].visitedList.get(jj).score;*/
                    //while(child[s].visitedList.contains(child[i].visitedList.get(jj))){
                                child[s].visitedList.remove(child[i].visitedList.get(jj));}
                           }
                        } 
                 //   }
                }
            }
       // }

        for(int i=0;i<child.length;i++)
        {
            child[i].score=0;
                child[i].remainingTourLength=0;
                child[i].tourLength=0;
            for(int j=2;j<child[i].visitedList.size();j++)
            {
                
                //child[i].score+=child[i].visitedList.get(j).score;
               // if(j<child[i].visitedList.size()-1&&j>2)
               // {
                        if (j == 2 && j != child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y);
                                        child[i].tourLength += ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y);
                                        //  break;
                                    }
                                    if (j == 2 && j == child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y));
                                        child[i].tourLength += (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y) + ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 2).x, child[i].visitedList.get(j - 2).y));
                                        //break;
                                    }
                                    if (j != 2 && j == child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y));
                                        child[i].tourLength += (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y) + ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y));
                                        // break;
                                    }
                                    if (j > 2 && j != child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y);
                                        child[i].tourLength += ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y);
                                        //  break;
                                    }
                                }
             //   }
            
        }
        for (int i = 0; i < child.length; i++) {
            while (child[i].tourLength > ge.tripLengthForEachTrip.get(i)) {

                if (child[i].visitedList.size() > 2) {
                    child[i].tourLength -= (ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y)+ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y));
                    //+ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size()-1).x, child[i].visitedList.get(child[i].visitedList.size()-1).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y);
                    child[i].tourLength += ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y);
                    child[i].remainingTourLength += ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y);
                    child[i].score -= child[i].visitedList.get(child[i].visitedList.size() - 1).score;
                    child[i].visitedList.remove(child[i].visitedList.size() - 1);
                }

            }
        }
        List<Place> used = new ArrayList();
        for (int i = 0; i < child.length; i++) {
            for (int j = 2; j < child[i].visitedList.size(); j++) {
                used.add(child[i].visitedList.get(j));
            }
        }
        List<Place> remain = new ArrayList();
        for (int i = 0; i < placeList.length; i++) {
            if (!used.contains(placeList[i])) {
                remain.add(placeList[i]);
            }
        }
        ge.Insert(child, remain,used);
        for(int i=0;i<child.length;i++)
        {
             child[i].score=0;
                child[i].remainingTourLength=0;
                child[i].tourLength=0;
            for(int j=2;j<child[i].visitedList.size();j++)
            {
               
                //child[i].score+=child[i].visitedList.get(j).score;
               // if(j<child[i].visitedList.size()-1&&j>2)
               // {
                        if (j == 2 && j != child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y);
                                        child[i].tourLength += ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y);
                                        //  break;
                                    }
                                    if (j == 2 && j == child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y));
                                        child[i].tourLength += (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y) + ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 2).x, child[i].visitedList.get(j - 2).y));
                                        //break;
                                    }
                                    if (j != 2 && j == child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y));
                                        child[i].tourLength += (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y) + ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y));
                                        // break;
                                    }
                                    if (j > 2 && j != child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y);
                                        child[i].tourLength += ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y);
                                        //  break;
                                    }
                                }
             //   }
            
        }
        for (int i = 0; i < child.length; i++) {
            while (child[i].tourLength > ge.tripLengthForEachTrip.get(i)) {

                if (child[i].visitedList.size() > 2) {
                    child[i].tourLength -= (ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y)+ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y));
                    //+ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size()-1).x, child[i].visitedList.get(child[i].visitedList.size()-1).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y);
                    child[i].tourLength += ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y);
                    child[i].remainingTourLength += ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y);
                    child[i].score -= child[i].visitedList.get(child[i].visitedList.size() - 1).score;
                    child[i].visitedList.remove(child[i].visitedList.size() - 1);
                }

            }
        }
        
         for(int i=0;i<child.length;i++)
        {
             child[i].score=0;
                child[i].remainingTourLength=0;
                child[i].tourLength=0;
            for(int j=2;j<child[i].visitedList.size();j++)
            {
               
                //child[i].score+=child[i].visitedList.get(j).score;
               // if(j<child[i].visitedList.size()-1&&j>2)
               // {
                        if (j == 2 && j != child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y);
                                        child[i].tourLength += ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y);
                                        //  break;
                                    }
                                    if (j == 2 && j == child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(0).x, child[i].visitedList.get(0).y));
                                        child[i].tourLength += (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y) + ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 2).x, child[i].visitedList.get(j - 2).y));
                                        //break;
                                    }
                                    if (j != 2 && j == child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y));
                                        child[i].tourLength += (ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y) + ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y));
                                        // break;
                                    }
                                    if (j > 2 && j != child[i].visitedList.size() - 1) {
                                        child[i].score += child[i].visitedList.get(j).score;
                                        child[i].remainingTourLength -= ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y);
                                        child[i].tourLength += ge.FindDistance(child[i].visitedList.get(j).x, child[i].visitedList.get(j).y, child[i].visitedList.get(j - 1).x, child[i].visitedList.get(j - 1).y);
                                        //  break;
                                    }
                                }
             //   }
            
        }
         for (int i = 0; i < child.length; i++) {
            while (child[i].tourLength > ge.tripLengthForEachTrip.get(i)) {

                if (child[i].visitedList.size() > 2) {
                    child[i].tourLength -= (ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y)+ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y));
                    //+ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size()-1).x, child[i].visitedList.get(child[i].visitedList.size()-1).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y);
                    child[i].tourLength += ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y);
                    child[i].remainingTourLength += ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size() - 2).x, child[i].visitedList.get(child[i].visitedList.size() - 2).y, child[i].visitedList.get(child[i].visitedList.size() - 1).x, child[i].visitedList.get(child[i].visitedList.size() - 1).y);
                    child[i].score -= child[i].visitedList.get(child[i].visitedList.size() - 1).score;
                    child[i].visitedList.remove(child[i].visitedList.size() - 1);
                }

            }
        }
        
        if (ge.SolutionTotalScore(child) > ge.SolutionTotalScore(ge.BestSolution)) {
            ge.BestSolution = new Trip[child.length];
            for (int i = 0; i < child.length; i++) {
                ge.BestSolution[i] = new Trip();
                ge.BestSolution[i].remainingTourLength = child[i].remainingTourLength;
                ge.BestSolution[i].score = child[i].score;
                ge.BestSolution[i].tourLength = child[i].tourLength;
                ge.BestSolution[i].visitedList = new ArrayList();
                for (int j = 0; j < child[i].visitedList.size(); j++) {
                    ge.BestSolution[i].visitedList.add(child[i].visitedList.get(j));
                }
            }
            Trip[] temp;
        temp=new Trip[numberOfTrips];
        for(int k=0;k<15;k++)
        {
            temp=new Trip[numberOfTrips];
            for(int i=0;i<child.length;i++)
            {
                temp[i]=new Trip();
                temp[i].remainingTourLength=child[i].remainingTourLength;
                temp[i].score=child[i].score;
                temp[i].tourLength=child[i].tourLength;
                temp[i].visitedList=new ArrayList();
                for(int j=0;j<child[i].visitedList.size();j++)
                {
                    temp[i].visitedList.add(child[i].visitedList.get(j));
                }
            }
        ge.LocalSearch(temp, remain,used);
        }
        if(ge.SolutionTotalScore(child)<ge.SolutionTotalScore(temp))
        {
             child=new Trip[numberOfTrips];
            for(int i=0;i<child.length;i++)
            {
                child[i]=new Trip();
                child[i].remainingTourLength=temp[i].remainingTourLength;
                child[i].score=temp[i].score;
                child[i].tourLength=temp[i].tourLength;
                child[i].visitedList=new ArrayList();
                for(int j=0;j<temp[i].visitedList.size();j++)
                {
                    child[i].visitedList.add(temp[i].visitedList.get(j));
                }
            }
            
        }
        ge.BestSolution = new Trip[child.length];
            for (int i = 0; i < child.length; i++) {
                ge.BestSolution[i] = new Trip();
                ge.BestSolution[i].remainingTourLength = child[i].remainingTourLength;
                ge.BestSolution[i].score = child[i].score;
                ge.BestSolution[i].tourLength = child[i].tourLength;
                ge.BestSolution[i].visitedList = new ArrayList();
                for (int j = 0; j < child[i].visitedList.size(); j++) {
                    ge.BestSolution[i].visitedList.add(child[i].visitedList.get(j));
                }
            }
        childrenList.add(child);
        }

    }
}
