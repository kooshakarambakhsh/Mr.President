import com.sun.corba.se.spi.orbutil.fsm.Input;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author koosha
 */
public class SimulatedAnnealing
{

    public Trip[] Solution;
    public Hotel[] hotelsList;
    public Place[] placeList;
    public int numberOfVertices;
    public int numberOfExtraHotels;
    public int numberOfPlaces;
    public int numberOfTrips;
    public int totalTourLength;
    public List<Double> tripLengthForEachTrip;
    public List<Place> remainingPlaces;
    public List<Place> RCL;
    public List<Place> CL;
    public List<Trip[]> SolutionList;
    public Trip[] BestSolution;
    public int time;
    public SimulatedAnnealing(int _numberOfVertices,int _numberOfExtraHotels,int _numberOfPlaces,int _numberOfTrips,int _totalTourLength,List _tripLengthForEachTrip,Hotel[] _hotelsList,Place[] _placeList)
    {
      numberOfVertices=_numberOfVertices;
      numberOfExtraHotels=_numberOfExtraHotels;
      numberOfPlaces=_numberOfPlaces;
      numberOfTrips=_numberOfTrips;
      totalTourLength=_totalTourLength;
      tripLengthForEachTrip=_tripLengthForEachTrip;
      hotelsList=_hotelsList;
      placeList=_placeList;
      BestSolution=new Trip[numberOfTrips];
    }
    public void initialization()
    {
         Solution=new Trip[numberOfTrips];
      remainingPlaces=new ArrayList();
     
      for(int i=0;i<placeList.length;i++)
      {
       placeList[i].ID=Integer.toString(i+hotelsList.length+1);
      }
      for(int i=0;i<hotelsList.length;i++)
      {
       hotelsList[i].ID=Integer.toString(i);
      }
       for(int i=0;i<placeList.length;i++)
      {
          remainingPlaces.add(placeList[i]);
      }
      for(int i=0;i<tripLengthForEachTrip.size();i++)
      {
          Solution[i]=new Trip();
          Solution[i].visitedList=new ArrayList();
          Solution[i].tourLength=tripLengthForEachTrip.get(i);
          Solution[i].remainingTourLength=tripLengthForEachTrip.get(i);
          Solution[i].score=0;
      }
      RCL=new ArrayList();
      CL=new ArrayList();
      
    }
    public Trip[] CreateSolution()
    {
        List<Hotel> selectedHotels=new ArrayList();
      /*Trip[] copy=new Trip[numberOfTrips];
         for(int i=0;i<Solution.length;i++)
         {
             copy[i]=new Trip();
             copy[i].remainingTourLength=Solution[i].remainingTourLength;
             copy[i].score=Solution[i].score;
             copy[i].tourLength=Solution[i].tourLength;
             copy[i].visitedList=new ArrayList();
             for(int j=0;j<Solution[i].visitedList.size();j++)
             {
                 copy[i].visitedList.add(Solution[i].visitedList.get(j));
             }
         }*/
        int randomValue=0;
        selectedHotels.add(hotelsList[0]);      
        for(int i=0;i<numberOfTrips-1;i++)
        {
           Random r=new Random();
           int id=r.nextInt(hotelsList.length);
           if(i<numberOfTrips-2){
           while(FindDistance(hotelsList[id].x,hotelsList[id].y,selectedHotels.get(selectedHotels.size()-1).x,selectedHotels.get(selectedHotels.size()-1).y)>tripLengthForEachTrip.get(i))
           {
               id=r.nextInt(hotelsList.length);
           }
           
           }
           else
           {
               while(FindDistance(hotelsList[id].x,hotelsList[id].y,selectedHotels.get(selectedHotels.size()-1).x,selectedHotels.get(selectedHotels.size()-1).y)>tripLengthForEachTrip.get(i)&&FindDistance(hotelsList[id].x,hotelsList[id].y,hotelsList[1].x,hotelsList[1].y)>tripLengthForEachTrip.get(numberOfTrips-1))
               {
                   id=r.nextInt(hotelsList.length);
               }
           }
           selectedHotels.add(hotelsList[id]);
        }
        selectedHotels.add(hotelsList[1]);
        
        //Solution[0].visitedList.add(selectedHotels.get(0));
        for(int i=0;i<selectedHotels.size()-1;i++)
        {
            Solution[i].visitedList.add(selectedHotels.get(i));
            Solution[i].visitedList.add(selectedHotels.get(i+1));
        }
        
        //making candidate list
        for(int i=0;i<Solution.length;i++)
        {
            CL=new ArrayList();
                RCL=new ArrayList();
            while(CandidateExist(Solution,i))
            {
                CL=new ArrayList();
                RCL=new ArrayList();
            for(int k=0;k<remainingPlaces.size();k++)
            {
                double dis=FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y,Solution[i].visitedList.get(Solution[i].visitedList.size()-1).x , Solution[i].visitedList.get(Solution[i].visitedList.size()-1).y)+FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y,Solution[i].visitedList.get(1).x,Solution[i].visitedList.get(1).y);
                if(Solution[i].remainingTourLength>=dis)
                {
                    CL.add(remainingPlaces.get(k));
                } 
            }
                sortByScore(CL,i,Solution[i].visitedList.size()-1,Solution);
                for(int s=0;s<CL.size();s++)
                {
                    RCL.add(CL.get(s));
                }
                Random r=new Random();
                
               // if(r.nextInt(100)<=75)
                //{
                    randomValue=0;
                //}
                //else{
                 randomValue=r.nextInt(RCL.size());
                //}
                Solution[i].remainingTourLength-=(FindDistance(RCL.get(randomValue).x,RCL.get(randomValue).y,Solution[i].visitedList.get(Solution[i].visitedList.size()-1).x,Solution[i].visitedList.get(Solution[i].visitedList.size()-1).y));
                Solution[i].visitedList.add(RCL.get(randomValue));
                Solution[i].score+=RCL.get(randomValue).score;
                
                remainingPlaces.remove(RCL.get(randomValue));
                RCL.remove(RCL.get(randomValue));

                
        }
          if(Solution[i].visitedList.size()>2){
            
            
            Solution[i].remainingTourLength-=(FindDistance(Solution[i].visitedList.get(Solution[i].visitedList.size()-1).x,Solution[i].visitedList.get(Solution[i].visitedList.size()-1).y,Solution[i].visitedList.get(1).x,Solution[i].visitedList.get(1).y));
        
    }  
            
        }
    
      
    return Solution;
    }

    public boolean CandidateExist(Trip[] sol,int index)
    {
        boolean result=false;
        CL=new ArrayList();
         for(int k=0;k<remainingPlaces.size();k++)
            {
                if(FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y,sol[index].visitedList.get(sol[index].visitedList.size()-1).x , sol[index].visitedList.get(sol[index].visitedList.size()-1).y)+FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y,sol[index].visitedList.get(1).x,sol[index].visitedList.get(1).y)<=sol[index].remainingTourLength)
                {
                    CL.add(remainingPlaces.get(k));
                }
            }
         if(CL.size()>0)
         {
             result=true;
         }
        return result;
    }
    public double FindDistance(double x1,double y1,double x2,double y2)
    {
        double result=Math.sqrt(Math.pow(x2-x1,2)+Math.pow(y2-y1, 2));
        return result;       
    }
    public void sortByScore(List<Place> input,int index,int index2,Trip[] t)
    {
        
        for(int i=0;i<input.size()-1;i++)
        {
            for(int j=i+1;j<input.size();j++)
            {
               if(input.get(i).score/FindDistance(input.get(i).x, input.get(i).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y)<input.get(j).score/FindDistance(input.get(j).x, input.get(j).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y))
               // if(input.get(i).score<input.get(j).score)
                {
                    Place temp=new Place();
                    temp.ID=input.get(i).ID;
                    temp.score=input.get(i).score;
                    temp.x=input.get(i).x;
                    temp.y=input.get(i).y;
                    input.get(i).ID=input.get(j).ID;
                    input.get(i).score=input.get(j).score;
                    input.get(i).x=input.get(j).x;
                    input.get(i).y=input.get(j).y;
                    input.get(j).ID=temp.ID;
                    input.get(j).score=temp.score;
                    input.get(j).x=temp.x;
                    input.get(j).y=temp.y;
                }
            }
        }
    }


    public double SolutionTotalScore(Trip[] input)
    {
        double result=0;
        for(int i=0;i<input.length;i++)
        {
            for(int j=2;j<input[i].visitedList.size();j++)
            {
            result+=input[i].visitedList.get(j).score;
            }
        }
        return result;
       
    }

    
    public Trip[] LocalSearch(Trip[] input,SimulatedAnnealing g)
    {
        Random r=new Random();
        Trip[] result=new Trip[input.length];
        
        for(int i=0;i<input.length;i++)
        {
            result[i]=new Trip();
            result[i].visitedList=new ArrayList();
            result[i].remainingTourLength=input[i].remainingTourLength;
            result[i].score=input[i].score;
            result[i].tourLength=input[i].tourLength;
            for(int j=0;j<input[i].visitedList.size();j++)
            {
                result[i].visitedList.add(input[i].visitedList.get(j));
            }
        }
        for(int i=0;i<result.length;i++)
        {
            if(result[i].visitedList.size()>2)
            {
                int randomSubList=r.nextInt(result[i].visitedList.size());
                while(randomSubList==0||randomSubList==result[i].visitedList.size()-1)
                {
                    randomSubList=r.nextInt(result[i].visitedList.size());
                }
                
                for(int j=0;j<randomSubList;j++)
                {
                    
                    g.remainingPlaces.add(result[i].visitedList.get(2));
                    result[i].visitedList.remove(2);
                }
            }
        }
        for(int i=result.length-1;i==0;i--){
                while(g.checkCandidateExistForLocalSearch(result, i,g))
                {
                CL=new ArrayList();
                RCL=new ArrayList();
            for(int k=0;k<g.remainingPlaces.size();k++)
            {
                double dis=FindDistance(g.remainingPlaces.get(k).x, g.remainingPlaces.get(k).y,result[i].visitedList.get(result[i].visitedList.size()-1).x , result[i].visitedList.get(result[i].visitedList.size()-1).y)+FindDistance(g.remainingPlaces.get(k).x, g.remainingPlaces.get(k).y,result[i].visitedList.get(1).x,result[i].visitedList.get(1).y);
                if(result[i].remainingTourLength>=dis)
                {
                    CL.add(g.remainingPlaces.get(k));
                } 
            }
                sortByScore(CL,i,result[i].visitedList.size()-1,result);
                for(int s=0;s<CL.size();s++)
                {
                    RCL.add(CL.get(s));
                }
                int randomValue=0;
                
                //if(r.nextInt(100)<=75)
                //{
                //    randomValue=0;
                //}
                //else{
                 randomValue=r.nextInt(RCL.size());
               // }
                result[i].remainingTourLength-=(FindDistance(RCL.get(randomValue).x,RCL.get(randomValue).y,result[i].visitedList.get(result[i].visitedList.size()-1).x,result[i].visitedList.get(result[i].visitedList.size()-1).y));
                result[i].visitedList.add(RCL.get(randomValue));
                result[i].score+=RCL.get(randomValue).score;
                
                g.remainingPlaces.remove(RCL.get(randomValue));
                RCL.remove(RCL.get(randomValue));
                
                
            }
            //return result;
            }

    
    //    }
     return result;
    }
    public boolean checkCandidateExistForLocalSearch(Trip[] sol,int index,SimulatedAnnealing s){
         boolean result=false;
        CL=new ArrayList();
         for(int k=0;k<s.remainingPlaces.size();k++)
            {
                if(FindDistance(s.remainingPlaces.get(k).x, s.remainingPlaces.get(k).y,sol[index].visitedList.get(sol[index].visitedList.size()-1).x , sol[index].visitedList.get(sol[index].visitedList.size()-1).y)+FindDistance(s.remainingPlaces.get(k).x, s.remainingPlaces.get(k).y,sol[index].visitedList.get(1).x,sol[index].visitedList.get(1).y)<=sol[index].remainingTourLength)
                {
                    CL.add(s.remainingPlaces.get(k));
                }
            }
         if(CL.size()>0)
         {
             result=true;
         }
        return result;
    }
    public double getLength(Trip[] input)
    {
        double result=0;
        for(int i=0;i<input.length;i++)
        {
            result+=(input[i].tourLength-input[i].remainingTourLength);
        }
        return result;
    }
  
  // }

}


