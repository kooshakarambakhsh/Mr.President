
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author koosha
 */
public class GeneticAlgorithm {

    public Trip[] Solution;
    public Hotel[] hotelsList;
    public Place[] placeList;
    public int numberOfVertices;
    public int numberOfExtraHotels;
    public int numberOfPlaces;
    public int numberOfTrips;
    public int totalTourLength;
    public List<Double> tripLengthForEachTrip;
    public List<Place> remainingPlaces;
    public List<Place> RCL;
    public List<Place> CL;
    public List<Trip[]> SolutionList;
    public Trip[] BestSolution;
    public int time;

    public GeneticAlgorithm(int _numberOfVertices, int _numberOfExtraHotels, int _numberOfPlaces, int _numberOfTrips, int _totalTourLength, List _tripLengthForEachTrip, Hotel[] _hotelsList, Place[] _placeList) {
        numberOfVertices = _numberOfVertices;
        numberOfExtraHotels = _numberOfExtraHotels;
        numberOfPlaces = _numberOfPlaces;
        numberOfTrips = _numberOfTrips;
        totalTourLength = _totalTourLength;
        tripLengthForEachTrip = _tripLengthForEachTrip;
        hotelsList = _hotelsList;
        placeList = _placeList;
        BestSolution = new Trip[numberOfTrips];
    }

    public void initialization() {
        //Solution = new Trip[numberOfTrips];
        remainingPlaces = new ArrayList();

        for (int i = 0; i < placeList.length; i++) {
            placeList[i].ID = Integer.toString(i + hotelsList.length + 1);
        }
        for (int i = 0; i < hotelsList.length; i++) {
            hotelsList[i].ID = Integer.toString(i);
        }
        for (int i = 0; i < placeList.length; i++) {
            remainingPlaces.add(placeList[i]);
        }

        RCL = new ArrayList();
        CL = new ArrayList();

    }

    public Trip[] CreateSolution(Trip[] input,Double[][] hotelMatrix) {
        List<Hotel> selectedHotels = new ArrayList();

       int randomValue=0;
        selectedHotels.add(hotelsList[0]);      
        for(int i=0;i<numberOfTrips-1;i++)
        {
           Random r=new Random();
           int id=r.nextInt(hotelsList.length);

           if(i<numberOfTrips-2){
           while(FindDistance(hotelsList[id].x,hotelsList[id].y,selectedHotels.get(selectedHotels.size()-1).x,selectedHotels.get(selectedHotels.size()-1).y)>tripLengthForEachTrip.get(i))
           {
               id=r.nextInt(hotelsList.length);
           }
           
           }
           else
           {
               while(FindDistance(hotelsList[id].x,hotelsList[id].y,selectedHotels.get(selectedHotels.size()-1).x,selectedHotels.get(selectedHotels.size()-1).y)>tripLengthForEachTrip.get(i)&&FindDistance(hotelsList[id].x,hotelsList[id].y,hotelsList[1].x,hotelsList[1].y)>tripLengthForEachTrip.get(numberOfTrips-1))
               {
                   id=r.nextInt(hotelsList.length);
               }
           }
           selectedHotels.add(hotelsList[id]);
        }
        selectedHotels.add(hotelsList[1]);
       // selectedHotels.add(hotelsList[1]);

        //Solution[0].visitedList.add(selectedHotels.get(0));
        for (int i = 0; i < selectedHotels.size() - 1; i++) {
            input[i].visitedList.add(selectedHotels.get(i));
            input[i].visitedList.add(selectedHotels.get(i + 1));
        }

        //making candidate list
        for (int i = 0; i < input.length; i++) {
           // CL = new ArrayList();
           // RCL = new ArrayList();
            while (CandidateExist(input, i)) {
                CL = new ArrayList();
                RCL = new ArrayList();
                for (int k = 0; k < remainingPlaces.size(); k++) {
                    double dis=0;
                    //if(input[i].visitedList.size()>2)
                    if(input[i].visitedList.size()>2)
                    {
                         dis = FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y) + FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                    }
                    else
                    {
                         dis = FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y) + FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                    }
                    
                    if (input[i].remainingTourLength >= dis) {
                        CL.add(remainingPlaces.get(k));
                    }
                }
                if(CL.size()>0){
                
                
                Random r = new Random();
                //RCL=CL;
                if (r.nextInt(100) <=95) {
                    sortByScorePerLength(CL, i, input[i].visitedList.size() - 1, input);
                    for (int s = 0; s < CL.size(); s++) {
                    RCL.add(CL.get(s));
                }
                randomValue = 0;
                  }
                      else
                     {
                         for (int s = 0; s < CL.size(); s++) {
                    RCL.add(CL.get(s));
                }
                 randomValue = r.nextInt(CL.size());
                      }
               // if(RCL.size()>0)
               // {
                
                
                if(input[i].visitedList.size()>2){
                    input[i].remainingTourLength -= (FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y));
                input[i].tourLength+=(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y));
                        //+(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                //input[i].tourLength-=FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                input[i].visitedList.add(RCL.get(randomValue));
                input[i].score += RCL.get(randomValue).score;
                }
                else
                {
                    input[i].remainingTourLength -= (FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y));
                    input[i].tourLength+=(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y));
                    //+(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                input[i].visitedList.add(RCL.get(randomValue));
                input[i].score += RCL.get(randomValue).score;
                }
                remainingPlaces.remove(RCL.get(randomValue));
                RCL.remove(RCL.get(randomValue));

           // }
            }}
            if (input[i].visitedList.size() > 2) {

               // input[i].remainingTourLength -= (FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                input[i].tourLength+=(FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
            }
            else
            {
                input[i].tourLength+=(FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
            }

        }

        return input;
    }
     public Trip[] CreateRandomSolution(Trip[] input,Double[][] hotelMatrix) {
        List<Hotel> selectedHotels = new ArrayList();

       int randomValue=0;
        selectedHotels.add(hotelsList[0]);      
        for(int i=0;i<numberOfTrips-1;i++)
        {
           Random r=new Random();
           int id=r.nextInt(hotelsList.length);

           if(i<numberOfTrips-2){
           while(FindDistance(hotelsList[id].x,hotelsList[id].y,selectedHotels.get(selectedHotels.size()-1).x,selectedHotels.get(selectedHotels.size()-1).y)>tripLengthForEachTrip.get(i))
           {
               id=r.nextInt(hotelsList.length);
           }
           
           }
           else
           {
               while(FindDistance(hotelsList[id].x,hotelsList[id].y,selectedHotels.get(selectedHotels.size()-1).x,selectedHotels.get(selectedHotels.size()-1).y)>tripLengthForEachTrip.get(i)&&FindDistance(hotelsList[id].x,hotelsList[id].y,hotelsList[1].x,hotelsList[1].y)>tripLengthForEachTrip.get(numberOfTrips-1))
               {
                   id=r.nextInt(hotelsList.length);
               }
           }
           selectedHotels.add(hotelsList[id]);
        }
        selectedHotels.add(hotelsList[1]);
       // selectedHotels.add(hotelsList[1]);

        //Solution[0].visitedList.add(selectedHotels.get(0));
        for (int i = 0; i < selectedHotels.size() - 1; i++) {
            input[i].visitedList.add(selectedHotels.get(i));
            input[i].visitedList.add(selectedHotels.get(i + 1));
        }

        //making candidate list
        for (int i = 0; i < input.length; i++) {
           // CL = new ArrayList();
           // RCL = new ArrayList();
            while (CandidateExist(input, i)) {
                CL = new ArrayList();
                RCL = new ArrayList();
                for (int k = 0; k < remainingPlaces.size(); k++) {
                    double dis=0;
                    //if(input[i].visitedList.size()>2)
                    if(input[i].visitedList.size()>2)
                    {
                         dis = FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y) + FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                    }
                    else
                    {
                         dis = FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y) + FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                    }
                    
                    if (input[i].remainingTourLength >= dis) {
                        CL.add(remainingPlaces.get(k));
                    }
                }
                if(CL.size()>0){
                
                
                Random r = new Random();
                //RCL=CL;
                //if (r.nextInt(100) <=95) {
                //    sortByScorePerLength(CL, i, input[i].visitedList.size() - 1, input);
                    for (int s = 0; s < CL.size(); s++) {
                    RCL.add(CL.get(s));
               // }
               // randomValue = 0;
               //   }
               //       else
               //      {
               //          for (int s = 0; s < CL.size(); s++) {
               //     RCL.add(CL.get(s));
               // }
                 randomValue = r.nextInt(CL.size());
                      }
               // if(RCL.size()>0)
               // {
                
                
                if(input[i].visitedList.size()>2){
                    input[i].remainingTourLength -= (FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y));
                input[i].tourLength+=(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y));
                        //+(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                //input[i].tourLength-=FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                input[i].visitedList.add(RCL.get(randomValue));
                input[i].score += RCL.get(randomValue).score;
                }
                else
                {
                    input[i].remainingTourLength -= (FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y));
                    input[i].tourLength+=(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y));
                    //+(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                input[i].visitedList.add(RCL.get(randomValue));
                input[i].score += RCL.get(randomValue).score;
                }
                remainingPlaces.remove(RCL.get(randomValue));
                RCL.remove(RCL.get(randomValue));

           // }
            }}
            if (input[i].visitedList.size() > 2) {

               // input[i].remainingTourLength -= (FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                input[i].tourLength+=(FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
            }
            else
            {
                input[i].tourLength+=(FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
            }

        }

        return input;
    }
public Trip[] CreateGraspSolution(Trip[] input,Double[][] hotelMatrix) {
        List<Hotel> selectedHotels = new ArrayList();

       int randomValue=0;
        selectedHotels.add(hotelsList[0]);      
        for(int i=0;i<numberOfTrips-1;i++)
        {
           Random r=new Random();
           int id=r.nextInt(hotelsList.length);

           if(i<numberOfTrips-2){
           while(FindDistance(hotelsList[id].x,hotelsList[id].y,selectedHotels.get(selectedHotels.size()-1).x,selectedHotels.get(selectedHotels.size()-1).y)>tripLengthForEachTrip.get(i))
           {
               id=r.nextInt(hotelsList.length);
           }
           
           }
           else
           {
               while(FindDistance(hotelsList[id].x,hotelsList[id].y,selectedHotels.get(selectedHotels.size()-1).x,selectedHotels.get(selectedHotels.size()-1).y)>tripLengthForEachTrip.get(i)&&FindDistance(hotelsList[id].x,hotelsList[id].y,hotelsList[1].x,hotelsList[1].y)>tripLengthForEachTrip.get(numberOfTrips-1))
               {
                   id=r.nextInt(hotelsList.length);
               }
           }
           selectedHotels.add(hotelsList[id]);
        }
        selectedHotels.add(hotelsList[1]);
       // selectedHotels.add(hotelsList[1]);

        //Solution[0].visitedList.add(selectedHotels.get(0));
        for (int i = 0; i < selectedHotels.size() - 1; i++) {
            input[i].visitedList.add(selectedHotels.get(i));
            input[i].visitedList.add(selectedHotels.get(i + 1));
        }

        //making candidate list
        for (int i = 0; i < input.length; i++) {
           // CL = new ArrayList();
           // RCL = new ArrayList();
            while (CandidateExist(input, i)) {
                CL = new ArrayList();
                RCL = new ArrayList();
                for (int k = 0; k < remainingPlaces.size(); k++) {
                    double dis=0;
                    //if(input[i].visitedList.size()>2)
                    if(input[i].visitedList.size()>2)
                    {
                         dis = FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y) + FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                    }
                    else
                    {
                         dis = FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y) + FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                    }
                    
                    if (input[i].remainingTourLength >= dis) {
                        CL.add(remainingPlaces.get(k));
                    }
                }
                if(CL.size()>0){
                
                
                Random r = new Random();
                RCL=CL;
                if (r.nextInt(100) <=75) {
                    sortByScorePerLength(CL, i, input[i].visitedList.size() - 1, input);
                    for (int s = 0; s < CL.size(); s++) {
                    RCL.add(CL.get(s));
                }
                randomValue = 0;
                  }
                      else
                     {
                         for (int s = 0; s < CL.size(); s++) {
                    RCL.add(CL.get(s));
                }
                 randomValue = r.nextInt(CL.size());
                      }
               // if(RCL.size()>0)
               // {
                
                
                if(input[i].visitedList.size()>2){
                    input[i].remainingTourLength -= (FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y));
                input[i].tourLength+=(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y));
                        //+(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                //input[i].tourLength-=FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                input[i].visitedList.add(RCL.get(randomValue));
                input[i].score += RCL.get(randomValue).score;
                }
                else
                {
                    input[i].remainingTourLength -= (FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y));
                    input[i].tourLength+=(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y));
                    //+(FindDistance(RCL.get(randomValue).x, RCL.get(randomValue).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                input[i].visitedList.add(RCL.get(randomValue));
                input[i].score += RCL.get(randomValue).score;
                }
                remainingPlaces.remove(RCL.get(randomValue));
                RCL.remove(RCL.get(randomValue));

           // }
            }}
            if (input[i].visitedList.size() > 2) {

               // input[i].remainingTourLength -= (FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                input[i].tourLength+=(FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
            }
            else
            {
                input[i].tourLength+=(FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
            }

        }

        return input;
    }
    public Trip[] CrossOver(Trip[] t1, Trip[] t2) {
        Trip[] child = new Trip[t1.length];;
        for (int i = 0; i < t1.length; i++) {
            int count = t1[i].visitedList.size() - 1;
            for (int j = 0; j < t2[i].visitedList.size(); j++) {
                if (!t1[i].visitedList.contains(t2[i].visitedList.get(j))) {

                    count++;
                }
            }
            Random r = new Random();
            int index1 = r.nextInt(t1[i].visitedList.size());
            int index2 = r.nextInt(t2[i].visitedList.size());

        }

        return child;
    }

    public void EvaluationFunction(Trip[] input) {
        int totalScore = 0;
        for (int i = 0; i < input.length; i++) {
            totalScore += input[i].score;
        }
    }

    public double FindDistance(double x1, double y1, double x2, double y2) {
        double result = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
        return result;
    }

    public boolean CandidateExist(Trip[] sol, int index) {
        boolean result = false;
        if(sol[index].visitedList.size()>2){
        CL = new ArrayList();
        for (int k = 0; k < remainingPlaces.size(); k++) {
            if (FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, sol[index].visitedList.get(sol[index].visitedList.size() - 1).x, sol[index].visitedList.get(sol[index].visitedList.size() - 1).y) + FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, sol[index].visitedList.get(1).x, sol[index].visitedList.get(1).y) <= sol[index].remainingTourLength) {
                CL.add(remainingPlaces.get(k));
                return true;
            }
        }}
        else
        {
           CL = new ArrayList();
        for (int k = 0; k < remainingPlaces.size(); k++) {
            if (FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, sol[index].visitedList.get(0).x, sol[index].visitedList.get(0).y) + FindDistance(remainingPlaces.get(k).x, remainingPlaces.get(k).y, sol[index].visitedList.get(1).x, sol[index].visitedList.get(1).y) <= sol[index].remainingTourLength) {
                CL.add(remainingPlaces.get(k));
                return true;
            }
        } 
        }
        return result;
    }
    
    public boolean CandidateExist(Trip[] sol, int index,List<Place> remain) {
        boolean result = false;
        CL = new ArrayList();
        for (int k = 0; k < remain.size(); k++) {
            if (FindDistance(remain.get(k).x, remain.get(k).y, sol[index].visitedList.get(sol[index].visitedList.size() - 1).x, sol[index].visitedList.get(sol[index].visitedList.size() - 1).y) + FindDistance(remain.get(k).x, remain.get(k).y, sol[index].visitedList.get(1).x, sol[index].visitedList.get(1).y) <= sol[index].remainingTourLength) {
                CL.add(remain.get(k));
                break;
            }
        }
        if (CL.size() > 0) {
            result = true;
        }
        return result;
    }

    public void sortByScore(List<Place> input, int index, int index2, Trip[] t) {

        for (int i = 0; i < input.size() - 1; i++) {
            for (int j = i + 1; j < input.size(); j++) {
              //  if (FindDistance(input.get(i).x, input.get(i).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y) / (input.get(i).score) > FindDistance(input.get(j).x, input.get(j).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y) / (input.get(j).score)) 
             if(input.get(i).score<input.get(j).score)
                // if(FindDistance(input.get(i).x, input.get(i).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y)<FindDistance(input.get(j).x, input.get(j).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y))
                {
                    Place temp = new Place();
                    temp.ID = input.get(i).ID;
                    temp.score = input.get(i).score;
                    temp.x = input.get(i).x;
                    temp.y = input.get(i).y;
                    input.get(i).ID = input.get(j).ID;
                    input.get(i).score = input.get(j).score;
                    input.get(i).x = input.get(j).x;
                    input.get(i).y = input.get(j).y;
                    input.get(j).ID = temp.ID;
                    input.get(j).score = temp.score;
                    input.get(j).x = temp.x;
                    input.get(j).y = temp.y;
                }
            }
        }
    }
    public void sortByScorePerLength(List<Place> input, int index, int index2, Trip[] t) {

        for (int i = 0; i < input.size() - 1; i++) {
            for (int j = i + 1; j < input.size(); j++) {
                if (FindDistance(input.get(i).x, input.get(i).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y) / (input.get(i).score) > FindDistance(input.get(j).x, input.get(j).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y) / (input.get(j).score)) 
             //if(input.get(i).score<input.get(j).score)
                // if(FindDistance(input.get(i).x, input.get(i).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y)<FindDistance(input.get(j).x, input.get(j).y, t[index].visitedList.get(index2).x, t[index].visitedList.get(index2).y))
                {
                    Place temp = new Place();
                    temp.ID = input.get(i).ID;
                    temp.score = input.get(i).score;
                    temp.x = input.get(i).x;
                    temp.y = input.get(i).y;
                    input.get(i).ID = input.get(j).ID;
                    input.get(i).score = input.get(j).score;
                    input.get(i).x = input.get(j).x;
                    input.get(i).y = input.get(j).y;
                    input.get(j).ID = temp.ID;
                    input.get(j).score = temp.score;
                    input.get(j).x = temp.x;
                    input.get(j).y = temp.y;
                }
            }
        }
    }

    public double getLength(Trip[] input) {
        double result = 0;
        for (int i = 0; i < input.length; i++) {
            result += (input[i].tourLength - input[i].remainingTourLength);
        }
        return result;
    }

    public double SolutionTotalScore(Trip[] input) {
        double result = 0;
        for (int i = 0; i < input.length; i++) {
            //for (int j = 2; j < input[i].visitedList.size(); j++) {
                result += input[i].score;
           // }
        }
        return result;

    }

    public void Insert(Trip[] input, List<Place> remain,List<Place> used) {
        for (int i = 0; i < input.length; i++) {
            while (CandidateExist(input, i,remain)) {
            CL = new ArrayList();
            for (int j = 0; j < remain.size(); j++) {
                

                if (FindDistance(remain.get(j).x, remain.get(j).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y) + FindDistance(remain.get(j).x, remain.get(j).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y) <= input[i].remainingTourLength) {
                    CL.add(remain.get(j));
                }
                
            }
            if (CL.size() > 0) {
                int index=0;
                Random r = new Random();
               // if(r.nextInt(100)>50)
              //  {
                    sortByScorePerLength(CL, i, input[i].visitedList.size() - 1, input);
                    index = 0;
             /*   }
                else
                {
                    sortByScore(CL, i, input[i].visitedList.size() - 1, input);
                   index=r.nextInt(CL.size());
                }
                
                */
                input[i].visitedList.add(CL.get(index));
                input[i].score += CL.get(index).score;
                double dist = FindDistance(CL.get(index).x, CL.get(index).y, input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y);
                input[i].remainingTourLength -= dist;
                input[i].tourLength += dist;
                remain.remove(CL.get(index));
                used.add(CL.get(index));
                CL.remove(index);
            }  
            
           // }
            if (input[i].visitedList.size() > 2) {

                //input[i].remainingTourLength -= (FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                input[i].tourLength+=(FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
            }
            else
            {
                input[i].tourLength+=(FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
            }
           // input[i].tourLength+= FindDistance(input[i].visitedList.get(input[i].visitedList.size()-1).x, input[i].visitedList.get(input[i].visitedList.size()-1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
        }}
    }

    public void delete(Trip[] input, List<Place> remain) {

    }

    public void Change(Trip[] input, List<Place> remain) {

    }

    public void LocalSearch(Trip[] input,List<Place> remain,List<Place> used) {
        Random r = new Random();
        int tripIndex = r.nextInt(input.length);
        int startIndexOfRemove=0;
       // for(int i=0;i<input.length;i++){
        while(input[tripIndex].visitedList.size()<3)
        {
            tripIndex =r.nextInt(input.length);
        }
            startIndexOfRemove = r.nextInt(input[tripIndex].visitedList.size()); 
        
        while(startIndexOfRemove<2)
        {
            startIndexOfRemove = r.nextInt(input[tripIndex].visitedList.size());
        }
        int count = input[tripIndex].visitedList.size() - startIndexOfRemove+1 ;
        while (count > 0) {
            remain.add(input[tripIndex].visitedList.get(startIndexOfRemove));
            input[tripIndex].visitedList.remove(startIndexOfRemove);
            
            count--;
        }
       for(int i=0;i<input.length;i++)
        {
            input[i].score=0;
                input[i].remainingTourLength=0;
                input[i].tourLength=0;
            for(int j=0;j<input[i].visitedList.size();j++)
            {
                
                if(j<input[i].visitedList.size()-1&&j>2)
                {
                        if (j == 2 && j != input[i].visitedList.size() - 1) {
                                        input[i].score += input[i].visitedList.get(j).score;
                                        input[i].remainingTourLength -= FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y);
                                        input[i].tourLength += FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y);
                                        //  break;
                                    }
                                    if (j == 2 && j == input[i].visitedList.size() - 1) {
                                        input[i].score += input[i].visitedList.get(j).score;
                                        input[i].remainingTourLength -= (FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(0).x, input[i].visitedList.get(0).y));
                                        input[i].tourLength += (FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y) + FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(j - 2).x, input[i].visitedList.get(j - 2).y));
                                        //break;
                                    }
                                    if (j != 2 && j == input[i].visitedList.size() - 1) {
                                        input[i].score += input[i].visitedList.get(j).score;
                                        input[i].remainingTourLength -= (FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(j - 1).x, input[i].visitedList.get(j - 1).y));
                                        input[i].tourLength += (FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y) + FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(j - 1).x, input[i].visitedList.get(j - 1).y));
                                        // break;
                                    }
                                    if (j > 2 && j != input[i].visitedList.size() - 1) {
                                        input[i].score += input[i].visitedList.get(j).score;
                                        input[i].remainingTourLength -= FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(j - 1).x, input[i].visitedList.get(j - 1).y);
                                        input[i].tourLength += FindDistance(input[i].visitedList.get(j).x, input[i].visitedList.get(j).y, input[i].visitedList.get(j - 1).x, input[i].visitedList.get(j - 1).y);
                                        //  break;
                                    }
                                }
                }
            
        }
       for (int i = 0; i < input.length; i++) {
            while (input[i].tourLength > tripLengthForEachTrip.get(i)) {

                if (input[i].visitedList.size() > 2) {
                    input[i].tourLength -= (FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y)+FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y));
                    //+ge.FindDistance(child[i].visitedList.get(child[i].visitedList.size()-1).x, child[i].visitedList.get(child[i].visitedList.size()-1).y, child[i].visitedList.get(1).x, child[i].visitedList.get(1).y);
                    input[i].tourLength += FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(1).x, input[i].visitedList.get(1).y);
                    input[i].remainingTourLength += FindDistance(input[i].visitedList.get(input[i].visitedList.size() - 2).x, input[i].visitedList.get(input[i].visitedList.size() - 2).y, input[i].visitedList.get(input[i].visitedList.size() - 1).x, input[i].visitedList.get(input[i].visitedList.size() - 1).y);
                    input[i].score -= input[i].visitedList.get(input[i].visitedList.size() - 1).score;
                    input[i].visitedList.remove(input[i].visitedList.size() - 1);
                }

            }
        }
       /*  List<Place> used = new ArrayList();
        for (int i = 0; i < input.length; i++) {
            for (int j = 2; j < input[i].visitedList.size(); j++) {
                used.add(input[i].visitedList.get(j));
            }
        }
       remain = new ArrayList();
        for (int i = 0; i < placeList.length; i++) {
            if (!used.contains(placeList[i])) {
                remain.add(placeList[i]);
            }
        }*/
        Insert(input, remain,used);
        }

        

    
}
